import json
import os
from typing import Dict, Optional, List
import streamlit as st

# the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# do not change this unless explicitly requested by the user
from openai import OpenAI

class AIRecommendations:
    """AI-powered weather recommendations using OpenAI"""
    
    def __init__(self):
        # Get API key from environment variables
        self.api_key = os.getenv("OPENAI_API_KEY", "your_openai_key_here")
        
        if self.api_key == "your_openai_key_here" or not self.api_key:
            self.client = None
        else:
            try:
                self.client = OpenAI(api_key=self.api_key)
            except Exception:
                self.client = None
    
    def get_recommendations(self, weather_data: Dict) -> Optional[Dict]:
        """
        Generate AI-powered recommendations based on weather data
        
        Args:
            weather_data: Dictionary containing current weather information
            
        Returns:
            Dictionary containing recommendations or None if failed
        """
        if not self.client:
            return self._get_fallback_recommendations(weather_data)
        
        try:
            # Prepare weather context for AI
            weather_context = self._format_weather_context(weather_data)
            
            prompt = f"""
            Based on the current weather conditions, provide practical recommendations in JSON format.
            
            Weather Context:
            {weather_context}
            
            Please provide recommendations in the following JSON structure:
            {{
                "clothing": ["specific clothing item 1", "specific clothing item 2", "etc"],
                "activities": ["recommended activity 1", "recommended activity 2", "etc"],
                "safety": ["safety precaution 1", "safety precaution 2", "etc"],
                "tips": ["practical tip 1", "practical tip 2", "etc"]
            }}
            
            Make recommendations specific to the weather conditions. Include practical advice for:
            - Appropriate clothing for the temperature, humidity, and wind
            - Suitable outdoor/indoor activities
            - Safety precautions for current weather conditions
            - General tips for comfort and well-being
            
            Limit each category to 3-5 items maximum.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a helpful weather advisor. Provide practical, specific recommendations based on current weather conditions. Always respond with valid JSON format."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"},
                max_tokens=1000,
                temperature=0.7
            )
            
            content = response.choices[0].message.content
            if content:
                try:
                    recommendations = json.loads(content)
                    return recommendations
                except json.JSONDecodeError:
                    return self._get_fallback_recommendations(weather_data)
            else:
                return self._get_fallback_recommendations(weather_data)
            
        except json.JSONDecodeError:
            return self._get_fallback_recommendations(weather_data)
        except Exception:
            return self._get_fallback_recommendations(weather_data)
    
    def _format_weather_context(self, weather_data: Dict) -> str:
        """Format weather data into a readable context for AI"""
        
        context = f"""
        Location: {weather_data['location']}
        Temperature: {weather_data['temperature']}°C (feels like {weather_data['feels_like']}°C)
        Weather: {weather_data['description']}
        Humidity: {weather_data['humidity']}%
        Wind Speed: {weather_data['wind_speed']} m/s
        Pressure: {weather_data['pressure']} hPa
        Visibility: {weather_data['visibility']} km
        Cloudiness: {weather_data['cloudiness']}%
        """
        
        return context.strip()
    
    def _get_fallback_recommendations(self, weather_data: Dict) -> Dict:
        """
        Provide basic rule-based recommendations when AI is not available
        
        Args:
            weather_data: Dictionary containing weather information
            
        Returns:
            Dictionary containing basic recommendations
        """
        temp = weather_data['temperature']
        humidity = weather_data['humidity']
        wind_speed = weather_data['wind_speed']
        description = weather_data['description'].lower()
        
        recommendations = {
            "clothing": [],
            "activities": [],
            "safety": [],
            "tips": []
        }
        
        # Temperature-based clothing recommendations
        if temp < 0:
            recommendations["clothing"].extend([
                "Heavy winter coat and layers",
                "Insulated boots and warm socks",
                "Hat, gloves, and scarf"
            ])
        elif temp < 10:
            recommendations["clothing"].extend([
                "Warm jacket or coat",
                "Long pants and closed shoes",
                "Light gloves and hat"
            ])
        elif temp < 20:
            recommendations["clothing"].extend([
                "Light jacket or sweater",
                "Long pants or jeans",
                "Comfortable walking shoes"
            ])
        elif temp < 30:
            recommendations["clothing"].extend([
                "Light clothing and breathable fabrics",
                "Shorts or light pants",
                "Sunglasses and light shoes"
            ])
        else:
            recommendations["clothing"].extend([
                "Minimal, light-colored clothing",
                "Sun hat and sunglasses",
                "Breathable, loose-fitting clothes"
            ])
        
        # Weather condition-specific recommendations
        if "rain" in description or "drizzle" in description:
            recommendations["clothing"].append("Waterproof jacket and umbrella")
            recommendations["safety"].append("Drive carefully on wet roads")
            recommendations["activities"].append("Indoor activities recommended")
        
        if "snow" in description:
            recommendations["safety"].extend([
                "Use caution when driving",
                "Clear sidewalks and driveways"
            ])
            recommendations["activities"].append("Consider winter sports")
        
        if wind_speed > 10:
            recommendations["safety"].append("Secure loose objects outdoors")
            recommendations["clothing"].append("Wind-resistant outer layer")
        
        if humidity > 80:
            recommendations["tips"].append("Stay hydrated and seek air conditioning")
        
        if temp > 30:
            recommendations["safety"].extend([
                "Avoid prolonged sun exposure",
                "Stay hydrated and seek shade"
            ])
        
        # General activity recommendations
        if temp > 15 and temp < 25 and "clear" in description:
            recommendations["activities"].extend([
                "Great weather for outdoor walking",
                "Perfect for picnics or outdoor dining"
            ])
        
        # General tips
        if temp < 5:
            recommendations["tips"].append("Keep emergency supplies in your car")
        
        recommendations["tips"].append("Check weather updates regularly")
        
        return recommendations
    
    def get_health_recommendations(self, weather_data: Dict, user_conditions: Optional[List[str]] = None) -> Optional[Dict]:
        """
        Generate health-specific recommendations based on weather and user conditions
        
        Args:
            weather_data: Dictionary containing weather information
            user_conditions: List of user health conditions (optional)
            
        Returns:
            Dictionary containing health recommendations
        """
        if not self.client:
            return None
        
        try:
            conditions_context = ""
            if user_conditions and len(user_conditions) > 0:
                conditions_context = f"User has the following health conditions: {', '.join(user_conditions)}"
            
            weather_context = self._format_weather_context(weather_data)
            
            prompt = f"""
            Provide health-specific recommendations based on current weather conditions.
            
            Weather Context:
            {weather_context}
            
            {conditions_context}
            
            Please provide health recommendations in JSON format:
            {{
                "general_health": ["recommendation 1", "recommendation 2"],
                "respiratory": ["breathing advice 1", "breathing advice 2"],
                "skin_care": ["skin protection 1", "skin protection 2"],
                "hydration": ["hydration tip 1", "hydration tip 2"]
            }}
            
            Focus on weather-related health impacts and preventive measures.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a health advisor specializing in weather-related health impacts. Provide practical health recommendations."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                response_format={"type": "json_object"},
                max_tokens=800,
                temperature=0.6
            )
            
            content = response.choices[0].message.content
            if content:
                return json.loads(content)
            else:
                return None
            
        except Exception:
            return None
