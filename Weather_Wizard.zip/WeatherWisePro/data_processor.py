import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import streamlit as st

class DataProcessor:
    """Process weather data for analytics and disaster detection"""
    
    def __init__(self):
        # Define thresholds for disaster conditions
        self.disaster_thresholds = {
            "extreme_heat": 35,  # Celsius
            "extreme_cold": -10,  # Celsius
            "high_wind": 20,  # m/s
            "very_high_wind": 30,  # m/s
            "low_pressure": 980,  # hPa
            "very_low_pressure": 960,  # hPa
            "high_humidity": 90,  # %
            "low_visibility": 1,  # km
        }
        
        # Weather condition codes that indicate severe weather
        self.severe_weather_codes = {
            200: "thunderstorm",
            201: "thunderstorm",
            202: "thunderstorm",
            210: "thunderstorm",
            211: "thunderstorm",
            212: "thunderstorm",
            221: "thunderstorm",
            230: "thunderstorm",
            231: "thunderstorm",
            232: "thunderstorm",
            502: "heavy_rain",
            503: "heavy_rain",
            504: "heavy_rain",
            511: "freezing_rain",
            520: "heavy_rain",
            521: "heavy_rain",
            522: "heavy_rain",
            531: "heavy_rain",
            600: "snow",
            601: "snow",
            602: "heavy_snow",
            611: "sleet",
            612: "sleet",
            613: "sleet",
            615: "sleet",
            616: "sleet",
            620: "snow",
            621: "snow",
            622: "heavy_snow",
            701: "mist",
            711: "smoke",
            721: "haze",
            731: "dust",
            741: "fog",
            751: "sand",
            761: "dust",
            762: "ash",
            771: "squalls",
            781: "tornado"
        }
    
    def check_disaster_conditions(self, weather_data: Dict) -> List[Dict]:
        """
        Analyze weather data for potential disaster conditions
        
        Args:
            weather_data: Dictionary containing weather information
            
        Returns:
            List of alert dictionaries
        """
        alerts = []
        
        # Check temperature extremes
        temp = weather_data['temperature']
        if temp >= self.disaster_thresholds["extreme_heat"]:
            alerts.append({
                "type": "Extreme Heat Warning",
                "severity": "high",
                "message": f"Temperature is {temp}°C. Heat stroke risk is high. Stay indoors and hydrated."
            })
        elif temp <= self.disaster_thresholds["extreme_cold"]:
            alerts.append({
                "type": "Extreme Cold Warning",
                "severity": "high",
                "message": f"Temperature is {temp}°C. Frostbite risk is high. Dress warmly and limit outdoor exposure."
            })
        
        # Check wind conditions
        wind_speed = weather_data['wind_speed']
        if wind_speed >= self.disaster_thresholds["very_high_wind"]:
            alerts.append({
                "type": "Severe Wind Warning",
                "severity": "high",
                "message": f"Wind speed is {wind_speed} m/s. Extremely dangerous conditions. Avoid outdoor activities."
            })
        elif wind_speed >= self.disaster_thresholds["high_wind"]:
            alerts.append({
                "type": "High Wind Advisory",
                "severity": "medium",
                "message": f"Wind speed is {wind_speed} m/s. Use caution outdoors and secure loose objects."
            })
        
        # Check atmospheric pressure
        pressure = weather_data['pressure']
        if pressure <= self.disaster_thresholds["very_low_pressure"]:
            alerts.append({
                "type": "Severe Weather Alert",
                "severity": "high",
                "message": f"Atmospheric pressure is very low ({pressure} hPa). Severe weather conditions possible."
            })
        elif pressure <= self.disaster_thresholds["low_pressure"]:
            alerts.append({
                "type": "Low Pressure Advisory",
                "severity": "medium",
                "message": f"Low atmospheric pressure ({pressure} hPa). Weather changes expected."
            })
        
        # Check visibility
        visibility = weather_data.get('visibility', 10)
        if visibility <= self.disaster_thresholds["low_visibility"]:
            alerts.append({
                "type": "Low Visibility Warning",
                "severity": "medium",
                "message": f"Visibility is only {visibility} km. Drive with extreme caution."
            })
        
        # Check severe weather conditions
        weather_code = weather_data['weather_code']
        if weather_code in self.severe_weather_codes:
            condition_type = self.severe_weather_codes[weather_code]
            
            if condition_type == "tornado":
                alerts.append({
                    "type": "Tornado Warning",
                    "severity": "high",
                    "message": "Tornado conditions detected. Seek immediate shelter in a basement or interior room."
                })
            elif condition_type == "thunderstorm":
                alerts.append({
                    "type": "Thunderstorm Warning",
                    "severity": "medium",
                    "message": "Thunderstorm conditions. Avoid outdoor activities and stay away from metal objects."
                })
            elif condition_type == "heavy_rain":
                alerts.append({
                    "type": "Heavy Rain Alert",
                    "severity": "medium",
                    "message": "Heavy rainfall detected. Risk of flooding. Avoid low-lying areas."
                })
            elif condition_type == "heavy_snow":
                alerts.append({
                    "type": "Heavy Snow Warning",
                    "severity": "medium",
                    "message": "Heavy snowfall conditions. Travel may be hazardous."
                })
            elif condition_type == "fog":
                alerts.append({
                    "type": "Dense Fog Advisory",
                    "severity": "low",
                    "message": "Dense fog conditions. Reduce speed and use headlights while driving."
                })
        
        # Check heat index for combined temperature and humidity
        heat_index = self._calculate_heat_index(temp, weather_data['humidity'])
        if heat_index >= 40:
            alerts.append({
                "type": "Heat Index Warning",
                "severity": "high",
                "message": f"Heat index is {heat_index:.1f}°C. Extreme caution advised. Heat exhaustion likely."
            })
        elif heat_index >= 32:
            alerts.append({
                "type": "Heat Index Advisory",
                "severity": "medium",
                "message": f"Heat index is {heat_index:.1f}°C. Caution advised. Fatigue possible with prolonged exposure."
            })
        
        return alerts
    
    def _calculate_heat_index(self, temp_c: float, humidity: float) -> float:
        """
        Calculate heat index (apparent temperature) in Celsius
        
        Args:
            temp_c: Temperature in Celsius
            humidity: Relative humidity percentage
            
        Returns:
            Heat index in Celsius
        """
        # Convert to Fahrenheit for calculation
        temp_f = temp_c * 9/5 + 32
        
        # Heat index formula (valid for temp >= 80°F and humidity >= 40%)
        if temp_f >= 80 and humidity >= 40:
            hi = (-42.379 + 2.04901523 * temp_f + 10.14333127 * humidity 
                  - 0.22475541 * temp_f * humidity - 0.00683783 * temp_f**2 
                  - 0.05481717 * humidity**2 + 0.00122874 * temp_f**2 * humidity 
                  + 0.00085282 * temp_f * humidity**2 - 0.00000199 * temp_f**2 * humidity**2)
            
            # Convert back to Celsius
            return (hi - 32) * 5/9
        else:
            # For lower temperatures/humidity, heat index approximates actual temperature
            return temp_c
    
    def analyze_trends(self, weather_history: List[Dict], location: str = None) -> Dict:
        """
        Analyze weather trends from historical data
        
        Args:
            weather_history: List of weather data dictionaries
            location: Specific location to analyze (optional)
            
        Returns:
            Dictionary containing trend analysis
        """
        if not weather_history:
            return {}
        
        df = pd.DataFrame(weather_history)
        
        # Filter by location if specified
        if location:
            df = df[df['location'] == location]
        
        if df.empty:
            return {}
        
        # Convert timestamp if it's not already datetime
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
        
        trends = {}
        
        # Temperature trends
        if 'temperature' in df.columns and len(df) > 1:
            temp_trend = self._calculate_trend(df['temperature'].values)
            trends['temperature'] = {
                'current': df['temperature'].iloc[-1],
                'trend': temp_trend,
                'min': df['temperature'].min(),
                'max': df['temperature'].max(),
                'avg': df['temperature'].mean()
            }
        
        # Humidity trends
        if 'humidity' in df.columns and len(df) > 1:
            humidity_trend = self._calculate_trend(df['humidity'].values)
            trends['humidity'] = {
                'current': df['humidity'].iloc[-1],
                'trend': humidity_trend,
                'min': df['humidity'].min(),
                'max': df['humidity'].max(),
                'avg': df['humidity'].mean()
            }
        
        # Pressure trends
        if 'pressure' in df.columns and len(df) > 1:
            pressure_trend = self._calculate_trend(df['pressure'].values)
            trends['pressure'] = {
                'current': df['pressure'].iloc[-1],
                'trend': pressure_trend,
                'min': df['pressure'].min(),
                'max': df['pressure'].max(),
                'avg': df['pressure'].mean()
            }
        
        # Wind speed trends
        if 'wind_speed' in df.columns and len(df) > 1:
            wind_trend = self._calculate_trend(df['wind_speed'].values)
            trends['wind_speed'] = {
                'current': df['wind_speed'].iloc[-1],
                'trend': wind_trend,
                'min': df['wind_speed'].min(),
                'max': df['wind_speed'].max(),
                'avg': df['wind_speed'].mean()
            }
        
        return trends
    
    def _calculate_trend(self, values: np.ndarray) -> str:
        """
        Calculate trend direction from a series of values
        
        Args:
            values: Array of numeric values
            
        Returns:
            Trend direction: 'increasing', 'decreasing', or 'stable'
        """
        if len(values) < 2:
            return 'stable'
        
        # Use linear regression to determine trend
        x = np.arange(len(values))
        slope = np.polyfit(x, values, 1)[0]
        
        # Define threshold for what constitutes a trend
        threshold = np.std(values) * 0.1
        
        if slope > threshold:
            return 'increasing'
        elif slope < -threshold:
            return 'decreasing'
        else:
            return 'stable'
    
    def get_weather_statistics(self, weather_history: List[Dict], days: int = 7) -> Dict:
        """
        Calculate weather statistics for the specified number of days
        
        Args:
            weather_history: List of weather data dictionaries
            days: Number of days to analyze
            
        Returns:
            Dictionary containing weather statistics
        """
        if not weather_history:
            return {}
        
        df = pd.DataFrame(weather_history)
        
        # Filter to last N days
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            cutoff_date = df['timestamp'].max() - timedelta(days=days)
            df = df[df['timestamp'] >= cutoff_date]
        
        if df.empty:
            return {}
        
        stats = {}
        
        # Temperature statistics
        if 'temperature' in df.columns:
            stats['temperature'] = {
                'min': df['temperature'].min(),
                'max': df['temperature'].max(),
                'mean': df['temperature'].mean(),
                'std': df['temperature'].std()
            }
        
        # Most common weather condition
        if 'description' in df.columns:
            most_common = df['description'].mode()
            stats['most_common_weather'] = most_common.iloc[0] if not most_common.empty else 'N/A'
        
        # Average wind speed
        if 'wind_speed' in df.columns:
            stats['avg_wind_speed'] = df['wind_speed'].mean()
        
        # Average humidity
        if 'humidity' in df.columns:
            stats['avg_humidity'] = df['humidity'].mean()
        
        return stats
