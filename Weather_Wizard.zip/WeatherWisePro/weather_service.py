import requests
import os
from typing import Dict, Optional, List
import streamlit as st

class WeatherService:
    """Service for fetching weather data from OpenWeatherMap API"""
    
    def __init__(self):
        # Get API key from environment variables
        self.api_key = os.getenv("OPENWEATHERMAP_API_KEY", "your_api_key_here")
        self.base_url = "https://api.openweathermap.org/data/2.5"
        
        if self.api_key == "your_api_key_here":
            st.warning("⚠️ OpenWeatherMap API key not found in environment variables. Please set OPENWEATHERMAP_API_KEY.")
    
    def get_current_weather(self, location: str) -> Optional[Dict]:
        """
        Fetch current weather data for a given location
        
        Args:
            location: City name or coordinates
            
        Returns:
            Dictionary containing weather data or None if failed
        """
        try:
            # Current weather endpoint
            url = f"{self.base_url}/weather"
            params = {
                "q": location,
                "appid": self.api_key,
                "units": "metric"  # Use Celsius
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Extract and format relevant data
            weather_data = {
                "location": f"{data['name']}, {data['sys']['country']}",
                "temperature": round(data['main']['temp'], 1),
                "feels_like": round(data['main']['feels_like'], 1),
                "humidity": data['main']['humidity'],
                "pressure": data['main']['pressure'],
                "wind_speed": round(data['wind']['speed'], 1),
                "wind_direction": data['wind'].get('deg', 0),
                "visibility": round(data.get('visibility', 0) / 1000, 1),  # Convert to km
                "weather_code": data['weather'][0]['id'],
                "description": data['weather'][0]['description'],
                "icon": data['weather'][0]['icon'],
                "cloudiness": data['clouds']['all'],
                "sunrise": data['sys']['sunrise'],
                "sunset": data['sys']['sunset'],
                "timezone": data.get('timezone', 0),
                "coordinates": {
                    "lat": data['coord']['lat'],
                    "lon": data['coord']['lon']
                }
            }
            
            return weather_data
            
        except requests.exceptions.RequestException as e:
            st.error(f"Network error fetching weather for {location}: {str(e)}")
            return None
        except KeyError as e:
            st.error(f"Invalid response format for {location}: {str(e)}")
            return None
        except Exception as e:
            st.error(f"Unexpected error fetching weather for {location}: {str(e)}")
            return None
    
    def get_forecast(self, location: str, days: int = 5) -> Optional[List[Dict]]:
        """
        Fetch weather forecast for a given location
        
        Args:
            location: City name or coordinates
            days: Number of days for forecast (max 5 for free tier)
            
        Returns:
            List of dictionaries containing forecast data or None if failed
        """
        try:
            url = f"{self.base_url}/forecast"
            params = {
                "q": location,
                "appid": self.api_key,
                "units": "metric",
                "cnt": days * 8  # 8 forecasts per day (3-hour intervals)
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            forecast_list = []
            for item in data['list']:
                forecast_data = {
                    "datetime": item['dt'],
                    "temperature": round(item['main']['temp'], 1),
                    "feels_like": round(item['main']['feels_like'], 1),
                    "humidity": item['main']['humidity'],
                    "pressure": item['main']['pressure'],
                    "wind_speed": round(item['wind']['speed'], 1),
                    "weather_code": item['weather'][0]['id'],
                    "description": item['weather'][0]['description'],
                    "icon": item['weather'][0]['icon'],
                    "cloudiness": item['clouds']['all'],
                    "rain": item.get('rain', {}).get('3h', 0),
                    "snow": item.get('snow', {}).get('3h', 0)
                }
                forecast_list.append(forecast_data)
            
            return forecast_list
            
        except requests.exceptions.RequestException as e:
            st.error(f"Network error fetching forecast for {location}: {str(e)}")
            return None
        except Exception as e:
            st.error(f"Error fetching forecast for {location}: {str(e)}")
            return None
    
    def get_air_quality(self, lat: float, lon: float) -> Optional[Dict]:
        """
        Fetch air quality data for given coordinates
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary containing air quality data or None if failed
        """
        try:
            url = f"{self.base_url}/air_pollution"
            params = {
                "lat": lat,
                "lon": lon,
                "appid": self.api_key
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data['list']:
                aqi_data = data['list'][0]
                air_quality = {
                    "aqi": aqi_data['main']['aqi'],  # 1-5 scale
                    "co": aqi_data['components']['co'],
                    "no": aqi_data['components']['no'],
                    "no2": aqi_data['components']['no2'],
                    "o3": aqi_data['components']['o3'],
                    "so2": aqi_data['components']['so2'],
                    "pm2_5": aqi_data['components']['pm2_5'],
                    "pm10": aqi_data['components']['pm10'],
                    "nh3": aqi_data['components']['nh3']
                }
                return air_quality
            
            return None
            
        except requests.exceptions.RequestException as e:
            st.error(f"Network error fetching air quality: {str(e)}")
            return None
        except Exception as e:
            st.error(f"Error fetching air quality: {str(e)}")
            return None
    
    def validate_api_key(self) -> bool:
        """
        Validate if the API key is working
        
        Returns:
            True if API key is valid, False otherwise
        """
        try:
            url = f"{self.base_url}/weather"
            params = {
                "q": "London",
                "appid": self.api_key
            }
            
            response = requests.get(url, params=params, timeout=5)
            return response.status_code == 200
            
        except Exception:
            return False
