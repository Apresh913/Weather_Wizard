import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import pandas as pd
import time
from weather_service import WeatherService
from ai_recommendations import AIRecommendations
from data_processor import DataProcessor
from utils import format_temperature, get_weather_icon, format_time

# Page configuration
st.set_page_config(
    page_title="Weather Analytics Dashboard",
    page_icon="🌦️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize services
@st.cache_resource
def init_services():
    weather_service = WeatherService()
    ai_recommendations = AIRecommendations()
    data_processor = DataProcessor()
    return weather_service, ai_recommendations, data_processor

weather_service, ai_recommendations, data_processor = init_services()

# Initialize session state
if 'weather_history' not in st.session_state:
    st.session_state.weather_history = []
if 'selected_locations' not in st.session_state:
    st.session_state.selected_locations = ['New York']
if 'last_update' not in st.session_state:
    st.session_state.last_update = None

# Main title
st.title("🌦️ Real-Time Weather & Disaster Analytics")
st.markdown("**Live weather monitoring with AI-powered insights and disaster alerts**")

# Sidebar for location management
with st.sidebar:
    st.header("📍 Location Settings")
    
    # Popular cities for auto-suggestions
    popular_cities = [
        "New York", "London", "Tokyo", "Paris", "Sydney", "Mumbai", "Berlin", "Toronto", 
        "Los Angeles", "Chicago", "Miami", "Dubai", "Singapore", "Hong Kong", "Moscow",
        "Madrid", "Rome", "Amsterdam", "Stockholm", "Copenhagen", "Vienna", "Prague",
        "Bangkok", "Seoul", "Mexico City", "São Paulo", "Buenos Aires", "Cairo", "Lagos",
        "Johannesburg", "Istanbul", "Athens", "Barcelona", "Lisbon", "Dublin", "Oslo",
        "Helsinki", "Warsaw", "Budapest", "Zurich", "Geneva", "Brussels", "Luxembourg",
        "Montreal", "Vancouver", "Boston", "San Francisco", "Seattle", "Denver", "Austin"
    ]
    
    # Single search bar with auto-suggestions
    location_to_add = st.selectbox(
        "Search & Add Location", 
        options=[""] + popular_cities,
        index=0,
        help="Select from popular cities or type any city name"
    )
    
    if st.button("Add Location") and location_to_add:
        if location_to_add not in st.session_state.selected_locations:
            st.session_state.selected_locations.append(location_to_add)
            st.success(f"Added {location_to_add}")
            st.rerun()
        else:
            st.warning("Location already added")
    
    # Manage existing locations
    st.subheader("Current Locations")
    for i, location in enumerate(st.session_state.selected_locations):
        col1, col2 = st.columns([3, 1])
        with col1:
            st.write(f"📍 {location}")
        with col2:
            if st.button("×", key=f"remove_{i}", help=f"Remove {location}"):
                st.session_state.selected_locations.remove(location)
                st.rerun()
    
    # Auto-refresh settings
    st.header("🔄 Refresh Settings")
    auto_refresh = st.checkbox("Auto-refresh data", value=True)
    refresh_interval = st.selectbox("Refresh interval", [30, 60, 300, 600], index=1, format_func=lambda x: f"{x//60} minutes" if x >= 60 else f"{x} seconds")
    
    if auto_refresh:
        if st.session_state.last_update is None or time.time() - st.session_state.last_update > refresh_interval:
            st.session_state.last_update = time.time()
            st.rerun()

# Main content area
if not st.session_state.selected_locations:
    st.warning("Please add at least one location to get started.")
    st.stop()

# Fetch current weather data for all locations
current_weather_data = []
for location in st.session_state.selected_locations:
    try:
        with st.spinner(f"Fetching weather data for {location}..."):
            weather_data = weather_service.get_current_weather(location)
            if weather_data:
                current_weather_data.append(weather_data)
    except Exception as e:
        st.error(f"Failed to fetch weather for {location}: {str(e)}")

if not current_weather_data:
    st.error("Unable to fetch weather data for any location. Please check your internet connection and try again.")
    st.stop()

# Current Weather Overview
st.header("🌡️ Current Weather Conditions")

# Create columns for current weather cards
cols = st.columns(min(len(current_weather_data), 3))
for i, weather_data in enumerate(current_weather_data):
    with cols[i % 3]:
        # Weather card
        with st.container():
            st.subheader(f"{weather_data['location']}")
            
            # Main metrics
            col1, col2 = st.columns(2)
            with col1:
                st.metric(
                    "Temperature",
                    format_temperature(weather_data['temperature']),
                    delta=f"Feels like {format_temperature(weather_data['feels_like'])}"
                )
            with col2:
                st.write(f"**{weather_data['description'].title()}**")
                st.write(f"{get_weather_icon(weather_data['weather_code'])}")
            
            # Additional metrics
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Humidity", f"{weather_data['humidity']}%")
                st.metric("Pressure", f"{weather_data['pressure']} hPa")
            with col2:
                st.metric("Wind Speed", f"{weather_data['wind_speed']} m/s")
                st.metric("Visibility", f"{weather_data.get('visibility', 'N/A')} km")

# Disaster Alerts
st.header("🚨 Weather Alerts & Warnings")
alert_container = st.container()

with alert_container:
    alerts_found = False
    for weather_data in current_weather_data:
        alerts = data_processor.check_disaster_conditions(weather_data)
        if alerts:
            alerts_found = True
            for alert in alerts:
                if alert['severity'] == 'high':
                    st.error(f"🚨 **{alert['type']}** in {weather_data['location']}: {alert['message']}")
                elif alert['severity'] == 'medium':
                    st.warning(f"⚠️ **{alert['type']}** in {weather_data['location']}: {alert['message']}")
                else:
                    st.info(f"ℹ️ **{alert['type']}** in {weather_data['location']}: {alert['message']}")
    
    if not alerts_found:
        st.success("✅ No weather alerts at this time")

# AI Recommendations
st.header("🤖 AI-Powered Recommendations")

# Get AI recommendations for the first location (or primary location)
primary_weather = current_weather_data[0] if current_weather_data else None
if primary_weather:
    try:
        with st.spinner("Generating recommendations..."):
            recommendations = ai_recommendations.get_recommendations(primary_weather)
            
            if recommendations:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.subheader("👕 Clothing Suggestions")
                    if 'clothing' in recommendations:
                        for item in recommendations['clothing']:
                            st.write(f"→ {item}")
                    
                    st.subheader("🏃‍♂️ Activity Recommendations")
                    if 'activities' in recommendations:
                        for activity in recommendations['activities']:
                            st.write(f"→ {activity}")
                
                with col2:
                    st.subheader("⚠️ Safety Precautions")
                    if 'safety' in recommendations:
                        for precaution in recommendations['safety']:
                            st.write(f"→ {precaution}")
                    
                    st.subheader("💡 General Tips")
                    if 'tips' in recommendations:
                        for tip in recommendations['tips']:
                            st.write(f"→ {tip}")
            else:
                st.info("💡 AI recommendations are temporarily unavailable. Using smart weather-based suggestions instead!")
                # Show fallback recommendations
                fallback_recommendations = ai_recommendations._get_fallback_recommendations(primary_weather)
                if fallback_recommendations:
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.subheader("👕 Clothing Suggestions")
                        if 'clothing' in fallback_recommendations:
                            for item in fallback_recommendations['clothing']:
                                st.write(f"→ {item}")
                        
                        st.subheader("🏃‍♂️ Activity Recommendations")
                        if 'activities' in fallback_recommendations:
                            for activity in fallback_recommendations['activities']:
                                st.write(f"→ {activity}")
                    
                    with col2:
                        st.subheader("⚠️ Safety Precautions")
                        if 'safety' in fallback_recommendations:
                            for precaution in fallback_recommendations['safety']:
                                st.write(f"→ {precaution}")
                        
                        st.subheader("💡 General Tips")
                        if 'tips' in fallback_recommendations:
                            for tip in fallback_recommendations['tips']:
                                st.write(f"→ {tip}")
    except Exception as e:
        st.warning("AI recommendations temporarily unavailable, but your weather data is working perfectly!")

# Historical Data and Trends
st.header("📊 Weather Analytics & Trends")

# Add current data to history
current_time = datetime.now()
for weather_data in current_weather_data:
    weather_data['timestamp'] = current_time
    st.session_state.weather_history.append(weather_data.copy())

# Keep only last 100 records per location to manage memory
location_counts = {}
filtered_history = []
for record in reversed(st.session_state.weather_history):
    location = record['location']
    if location_counts.get(location, 0) < 100:
        filtered_history.append(record)
        location_counts[location] = location_counts.get(location, 0) + 1

st.session_state.weather_history = list(reversed(filtered_history))

# Create charts if we have historical data
if len(st.session_state.weather_history) > 1:
    df = pd.DataFrame(st.session_state.weather_history)
    
    # Temperature trends
    st.subheader("🌡️ Temperature Trends")
    fig_temp = px.line(
        df, 
        x='timestamp', 
        y='temperature', 
        color='location',
        title='Temperature Over Time',
        labels={'temperature': 'Temperature (°C)', 'timestamp': 'Time'}
    )
    fig_temp.update_layout(height=400)
    st.plotly_chart(fig_temp, use_container_width=True)
    
    # Multi-metric comparison
    st.subheader("📈 Multi-Metric Analysis")
    
    tab1, tab2, tab3 = st.tabs(["🌡️ Temperature & Humidity", "💨 Wind & Pressure", "🌧️ Weather Conditions"])
    
    with tab1:
        fig_temp_humid = go.Figure()
        
        for location in df['location'].unique():
            location_data = df[df['location'] == location]
            fig_temp_humid.add_trace(go.Scatter(
                x=location_data['timestamp'],
                y=location_data['temperature'],
                mode='lines+markers',
                name=f'{location} - Temperature',
                yaxis='y'
            ))
            fig_temp_humid.add_trace(go.Scatter(
                x=location_data['timestamp'],
                y=location_data['humidity'],
                mode='lines+markers',
                name=f'{location} - Humidity',
                yaxis='y2'
            ))
        
        fig_temp_humid.update_layout(
            title='Temperature and Humidity Trends',
            xaxis_title='Time',
            yaxis=dict(title='Temperature (°C)', side='left'),
            yaxis2=dict(title='Humidity (%)', side='right', overlaying='y'),
            height=400
        )
        st.plotly_chart(fig_temp_humid, use_container_width=True)
    
    with tab2:
        col1, col2 = st.columns(2)
        
        with col1:
            fig_wind = px.line(
                df, 
                x='timestamp', 
                y='wind_speed', 
                color='location',
                title='Wind Speed Trends',
                labels={'wind_speed': 'Wind Speed (m/s)', 'timestamp': 'Time'}
            )
            st.plotly_chart(fig_wind, use_container_width=True)
        
        with col2:
            fig_pressure = px.line(
                df, 
                x='timestamp', 
                y='pressure', 
                color='location',
                title='Atmospheric Pressure Trends',
                labels={'pressure': 'Pressure (hPa)', 'timestamp': 'Time'}
            )
            st.plotly_chart(fig_pressure, use_container_width=True)
    
    with tab3:
        # Weather condition distribution
        condition_counts = df.groupby(['location', 'description']).size().reset_index()
        condition_counts.columns = ['location', 'description', 'count']
        fig_conditions = px.bar(
            condition_counts,
            x='location',
            y='count',
            color='description',
            title='Weather Condition Distribution',
            labels={'count': 'Frequency', 'location': 'Location'}
        )
        st.plotly_chart(fig_conditions, use_container_width=True)

# Location Comparison
if len(current_weather_data) > 1:
    st.header("🌍 Location Comparison")
    
    comparison_df = pd.DataFrame(current_weather_data)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Temperature comparison
        fig_temp_compare = px.bar(
            comparison_df,
            x='location',
            y='temperature',
            title='Temperature Comparison',
            labels={'temperature': 'Temperature (°C)', 'location': 'Location'},
            color='temperature',
            color_continuous_scale='RdYlBu_r'
        )
        st.plotly_chart(fig_temp_compare, use_container_width=True)
    
    with col2:
        # Humidity comparison
        fig_humid_compare = px.bar(
            comparison_df,
            x='location',
            y='humidity',
            title='Humidity Comparison',
            labels={'humidity': 'Humidity (%)', 'location': 'Location'},
            color='humidity',
            color_continuous_scale='Blues'
        )
        st.plotly_chart(fig_humid_compare, use_container_width=True)

# Footer with last update time
st.markdown("---")
if st.session_state.last_update:
    last_update_str = format_time(datetime.fromtimestamp(st.session_state.last_update))
    st.caption(f"Last updated: {last_update_str}")

# Manual refresh button
if st.button("🔄 Refresh Data", use_container_width=True):
    st.session_state.last_update = time.time()
    st.rerun()
