import streamlit as st
from datetime import datetime
from typing import Dict, Any
import pytz

def format_temperature(temp: float, unit: str = "C") -> str:
    """
    Format temperature with appropriate unit
    
    Args:
        temp: Temperature value
        unit: Temperature unit ('C' for Celsius, 'F' for Fahrenheit)
        
    Returns:
        Formatted temperature string
    """
    if unit.upper() == "F":
        return f"{temp:.1f}°F"
    else:
        return f"{temp:.1f}°C"

def celsius_to_fahrenheit(celsius: float) -> float:
    """Convert Celsius to Fahrenheit"""
    return (celsius * 9/5) + 32

def fahrenheit_to_celsius(fahrenheit: float) -> float:
    """Convert Fahrenheit to Celsius"""
    return (fahrenheit - 32) * 5/9

def get_weather_icon(weather_code: int) -> str:
    """
    Get emoji icon based on weather condition code
    
    Args:
        weather_code: OpenWeatherMap weather condition code
        
    Returns:
        Emoji representing the weather condition
    """
    icon_map = {
        # Thunderstorm group (2xx)
        200: "⛈️",  # thunderstorm with light rain
        201: "⛈️",  # thunderstorm with rain
        202: "⛈️",  # thunderstorm with heavy rain
        210: "🌩️",  # light thunderstorm
        211: "⛈️",  # thunderstorm
        212: "⛈️",  # heavy thunderstorm
        221: "⛈️",  # ragged thunderstorm
        230: "⛈️",  # thunderstorm with light drizzle
        231: "⛈️",  # thunderstorm with drizzle
        232: "⛈️",  # thunderstorm with heavy drizzle
        
        # Drizzle group (3xx)
        300: "🌦️",  # light intensity drizzle
        301: "🌦️",  # drizzle
        302: "🌦️",  # heavy intensity drizzle
        310: "🌦️",  # light intensity drizzle rain
        311: "🌦️",  # drizzle rain
        312: "🌦️",  # heavy intensity drizzle rain
        313: "🌦️",  # shower rain and drizzle
        314: "🌦️",  # heavy shower rain and drizzle
        321: "🌦️",  # shower drizzle
        
        # Rain group (5xx)
        500: "🌧️",  # light rain
        501: "🌧️",  # moderate rain
        502: "🌧️",  # heavy intensity rain
        503: "🌧️",  # very heavy rain
        504: "🌧️",  # extreme rain
        511: "🌨️",  # freezing rain
        520: "🌦️",  # light intensity shower rain
        521: "🌦️",  # shower rain
        522: "🌦️",  # heavy intensity shower rain
        531: "🌦️",  # ragged shower rain
        
        # Snow group (6xx)
        600: "🌨️",  # light snow
        601: "❄️",   # snow
        602: "❄️",   # heavy snow
        611: "🌨️",  # sleet
        612: "🌨️",  # light shower sleet
        613: "🌨️",  # shower sleet
        615: "🌨️",  # light rain and snow
        616: "🌨️",  # rain and snow
        620: "❄️",   # light shower snow
        621: "❄️",   # shower snow
        622: "❄️",   # heavy shower snow
        
        # Atmosphere group (7xx)
        701: "🌫️",  # mist
        711: "💨",  # smoke
        721: "🌫️",  # haze
        731: "💨",  # sand/dust whirls
        741: "🌫️",  # fog
        751: "💨",  # sand
        761: "💨",  # dust
        762: "🌋",  # volcanic ash
        771: "💨",  # squalls
        781: "🌪️",  # tornado
        
        # Clear group (800)
        800: "☀️",  # clear sky
        
        # Clouds group (80x)
        801: "🌤️",  # few clouds: 11-25%
        802: "⛅",  # scattered clouds: 25-50%
        803: "🌥️",  # broken clouds: 51-84%
        804: "☁️",  # overcast clouds: 85-100%
    }
    
    return icon_map.get(weather_code, "🌍")

def format_time(dt: datetime, timezone: str = None) -> str:
    """
    Format datetime object to readable string
    
    Args:
        dt: Datetime object
        timezone: Timezone string (optional)
        
    Returns:
        Formatted time string
    """
    if timezone:
        try:
            tz = pytz.timezone(timezone)
            dt = dt.astimezone(tz)
        except:
            pass  # Use original datetime if timezone conversion fails
    
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def get_wind_direction(degrees: float) -> str:
    """
    Convert wind direction degrees to compass direction
    
    Args:
        degrees: Wind direction in degrees
        
    Returns:
        Compass direction string
    """
    directions = [
        "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
        "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"
    ]
    
    # Normalize degrees to 0-360 range
    degrees = degrees % 360
    
    # Calculate index (16 directions, so 360/16 = 22.5 degrees per direction)
    index = round(degrees / 22.5) % 16
    
    return directions[index]

def get_air_quality_description(aqi: int) -> Dict[str, str]:
    """
    Get air quality description and color based on AQI value
    
    Args:
        aqi: Air Quality Index (1-5 scale)
        
    Returns:
        Dictionary with description and color
    """
    aqi_map = {
        1: {"description": "Good", "color": "green"},
        2: {"description": "Fair", "color": "yellow"},
        3: {"description": "Moderate", "color": "orange"},
        4: {"description": "Poor", "color": "red"},
        5: {"description": "Very Poor", "color": "purple"}
    }
    
    return aqi_map.get(aqi, {"description": "Unknown", "color": "gray"})

def calculate_wind_chill(temp_c: float, wind_speed_ms: float) -> float:
    """
    Calculate wind chill temperature in Celsius
    
    Args:
        temp_c: Temperature in Celsius
        wind_speed_ms: Wind speed in m/s
        
    Returns:
        Wind chill temperature in Celsius
    """
    # Convert wind speed from m/s to km/h
    wind_speed_kmh = wind_speed_ms * 3.6
    
    # Wind chill formula (valid for temp <= 10°C and wind >= 4.8 km/h)
    if temp_c <= 10 and wind_speed_kmh >= 4.8:
        wind_chill = (13.12 + 0.6215 * temp_c - 11.37 * (wind_speed_kmh ** 0.16) 
                     + 0.3965 * temp_c * (wind_speed_kmh ** 0.16))
        return round(wind_chill, 1)
    else:
        return temp_c

def validate_location_input(location: str) -> bool:
    """
    Validate location input
    
    Args:
        location: Location string to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not location or len(location.strip()) < 2:
        return False
    
    # Check for valid characters (letters, spaces, commas, hyphens)
    valid_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ,-.")
    if not all(char in valid_chars for char in location):
        return False
    
    return True

def get_uv_index_description(uv_index: float) -> Dict[str, str]:
    """
    Get UV index description and recommendations
    
    Args:
        uv_index: UV index value
        
    Returns:
        Dictionary with description, color, and recommendations
    """
    if uv_index < 3:
        return {
            "level": "Low",
            "color": "green",
            "recommendation": "No protection required"
        }
    elif uv_index < 6:
        return {
            "level": "Moderate",
            "color": "yellow",
            "recommendation": "Some protection required"
        }
    elif uv_index < 8:
        return {
            "level": "High",
            "color": "orange",
            "recommendation": "Protection essential"
        }
    elif uv_index < 11:
        return {
            "level": "Very High",
            "color": "red",
            "recommendation": "Extra protection required"
        }
    else:
        return {
            "level": "Extreme",
            "color": "purple",
            "recommendation": "Avoid sun exposure"
        }

@st.cache_data(ttl=300)  # Cache for 5 minutes
def cached_weather_data(location: str, timestamp: float) -> Dict:
    """
    Placeholder for cached weather data - used by Streamlit's caching system
    
    Args:
        location: Location string
        timestamp: Timestamp for cache invalidation
        
    Returns:
        Empty dict (actual implementation would fetch and cache data)
    """
    return {}

def safe_float_conversion(value: Any, default: float = 0.0) -> float:
    """
    Safely convert a value to float with fallback
    
    Args:
        value: Value to convert
        default: Default value if conversion fails
        
    Returns:
        Float value or default
    """
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

def safe_int_conversion(value: Any, default: int = 0) -> int:
    """
    Safely convert a value to int with fallback
    
    Args:
        value: Value to convert
        default: Default value if conversion fails
        
    Returns:
        Integer value or default
    """
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def truncate_text(text: str, max_length: int = 50) -> str:
    """
    Truncate text to specified length with ellipsis
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        
    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."
